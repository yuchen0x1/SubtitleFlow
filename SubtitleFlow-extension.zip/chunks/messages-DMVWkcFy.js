function s(t,e,n={}){return{type:t,payload:e,timestamp:Date.now(),...n}}function a(t){if(!t||typeof t!="object")return!1;const e=t;return typeof e.type=="string"&&typeof e.timestamp=="number"&&"payload"in e}export{a as i,s as m};
//# sourceMappingURL=messages-DMVWkcFy.js.map
